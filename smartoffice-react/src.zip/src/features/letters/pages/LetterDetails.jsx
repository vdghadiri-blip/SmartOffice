import { useParams } from "react-router-dom";

import {
    Card,
    CardContent,
    Typography,
    CircularProgress
} from "@mui/material";


import {
    useGetLetterQuery
} from "../api/lettersApi";



function LetterDetails() {


    const { id } = useParams();


    const {
        data: letter,
        isLoading
    } = useGetLetterQuery(id);



    if (isLoading)
        return <CircularProgress />;



    return (

        <Card>

            <CardContent>


                <Typography variant="h5">

                    {letter?.subject}

                </Typography>



                <Typography sx={{ mt: 2 }}>

                    فرستنده:
                    {letter?.fromUser}

                </Typography>



                <Typography>

                    گیرنده:
                    {letter?.toUser}

                </Typography>



                <Typography sx={{ mt: 3 }}>

                    {letter?.content}

                </Typography>



            </CardContent>


        </Card>

    );

}


export default LetterDetails;